<?php
/*
* Plugin Name: HTTPS Error Checker
* Description: Checks for HTTPS errors in the admin panel and allows to force SSL
* Version: 1.0
* Author: Nxvermore
* Author URI: https://ultbit.com
* License: None
*/

add_action( 'admin_notices', 'https_error_checker' );
function https_error_checker() {
    if ( ! is_ssl() ) {
        echo '<div class="error notice">';
        echo '<p>HTTPS error: Your website is not using a secure connection. Please enable SSL to ensure a secure connection.</p>';
        echo '<form method="post" action="">';
        echo '<input type="submit" name="force_ssl" value="Force SSL" class="button-primary">';
        echo '</form>';
        echo '</div>';
    }
}

add_action( 'admin_init', 'force_ssl' );
function force_ssl() {
    if ( isset( $_POST['force_ssl'] ) ) {
        // check if the user has the capability to edit the .htaccess file
        if ( current_user_can( 'manage_options' ) ) {
            $home_path = get_home_path();
            $htaccess_file = $home_path . '.htaccess';
            $mod_rewrite_enabled = in_array( 'mod_rewrite', apache_get_modules() );
            // check if the .htaccess file exists and mod_rewrite is enabled
            if ( file_exists( $htaccess_file ) && $mod_rewrite_enabled ) {
                $htaccess_contents = file_get_contents( $htaccess_file );
                // check if the .htaccess file already contains the SSL rule
                if ( strpos( $htaccess_contents, 'RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]' ) === false ) {
                    $new_htaccess_contents = "RewriteEngine On\nRewriteCond %{HTTPS} off\nRewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]\n" . $htaccess_contents;
                    file_put_contents( $htaccess_file, $new_htaccess_contents );
                    add_action( 'admin_notices', 'ssl_forced_notice' );
                } else {
                    add_action( 'admin_notices', 'ssl_already_forced_notice' );
                }
            } else {
                add_action( 'admin_notices', 'htaccess_error_notice' );
            }
        } else {
            add_action( 'admin_notices', 'permission_error_notice' );
        }
    }
}

function ssl_forced_notice() {
    echo '<div class="updated notice">';
    echo '<p>SSL has been successfully forced.</p>';
    echo '</div>';
}
function ssl_already_forced_notice() {
    echo '<div class="notice notice-warning">';
    echo '<p>SSL is already forced on your website.</p>';
    echo '</div>';
    }
    
    function htaccess_error_notice() {
    echo '<div class="notice notice-error">';
    echo '<p>There was an error modifying the .htaccess file. Please check the file permissions and make sure mod_rewrite is enabled.</p>';
    echo '</div>';
    }
    
    function permission_error_notice() {
    echo '<div class="notice notice-error">';
    echo '<p>You do not have permission to modify the .htaccess file. Please contact the website administrator.</p>';
    echo '</div>';
    }